//
//  ViewController.m
//  WFAdVideoDemo
//
//  Created by 冯宣超 on 2019/3/10.
//  Copyright © 2019年 冯宣超. All rights reserved.
//

#import "ViewController.h"
#import <WFAdVideoSDK/WFAdVideoSDK.h>

#define kBtnWidth 200

@interface ViewController ()

@property (nonatomic, strong) UITextField * textField;
@property (nonatomic, strong) UIButton    * loadBtn;
@property (nonatomic, strong) UIButton    * showBtn;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self.view addSubview:self.textField];
    [self.view addSubview:self.loadBtn];
    [self.view addSubview:self.showBtn];
}

#pragma mark - Method
- (void)onClickLoadVideoBtn:(UIButton *)btn {
    self.loadBtn.backgroundColor = [UIColor redColor];
    [WFAdVideoSDK loadVideoAd:self.textField.text UserId:@"uid"];
}

- (void)onClickShowVideoBtn:(UIButton *)btn {
    if ([WFAdVideoSDK adIsReadyToPlay]) {
        self.loadBtn.backgroundColor = [UIColor blueColor];
        [self.loadBtn setTitle:@"加载激励视频" forState:UIControlStateNormal];
        [WFAdVideoSDK showVideoAdOnViewController:self];
    } else {
        self.loadBtn.backgroundColor = [UIColor redColor];
        [self.loadBtn setTitle:@"视频正在下载" forState:UIControlStateNormal];
    }
}

#pragma mark - 延迟加载
- (UITextField *)textField {
    if (!_textField) {
        _textField = [[UITextField alloc] init];
        _textField.frame = CGRectMake(self.view.center.x - kBtnWidth/2, 200, kBtnWidth, 50);
        _textField.borderStyle = UITextBorderStyleRoundedRect;
        _textField.placeholder = @"请输入广告位ID";
        _textField.font = [UIFont systemFontOfSize:13];
        _textField.textColor = [UIColor blackColor];
        _textField.clearButtonMode = UITextFieldViewModeAlways;
        _textField.textAlignment = NSTextAlignmentLeft;
        _textField.keyboardType = UIKeyboardTypePhonePad;
    }
    return _textField;
}

- (UIButton *)loadBtn {
    if (!_loadBtn) {
        _loadBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _loadBtn.frame = CGRectMake(self.view.center.x - kBtnWidth/2, 400, kBtnWidth, 50);
        _loadBtn.backgroundColor = [UIColor blueColor];
        _loadBtn.layer.cornerRadius = 5;
        [_loadBtn setTitle:@"加载激励视频" forState:UIControlStateNormal];
        [_loadBtn addTarget:self action:@selector(onClickLoadVideoBtn:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _loadBtn;
}

- (UIButton *)showBtn {
    if (!_showBtn) {
        _showBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _showBtn.frame = CGRectMake(self.view.center.x - kBtnWidth/2, 500, kBtnWidth, 50);
        _showBtn.backgroundColor = [UIColor blueColor];
        _showBtn.layer.cornerRadius = 5;
        [_showBtn setTitle:@"展示激励视频" forState:UIControlStateNormal];
        [_showBtn addTarget:self action:@selector(onClickShowVideoBtn:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _showBtn;
}

#pragma mark - 触摸式事件
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.textField resignFirstResponder];
}
@end
