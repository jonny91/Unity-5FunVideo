package com.wufun.game.video.ad;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.wufun.pay.plug.wufunvideoadlib.VideoAdData;
import com.wufun.pay.plug.wufunvideoadlib.WufunVideoAdCenter;
import com.wufun.pay.plug.wufunvideoadlib.utils.StringUtils;
import com.wufun.pay.plug.wufunvideoadlib.utils.ToastUtils;

public class MainActivity extends AppCompatActivity {
    Activity activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        activity = this;
        Button videoload = findViewById(R.id.videoload);
        final Button videoshow = findViewById(R.id.videoshow);
        final Button twolevel = findViewById(R.id.twolevel);
        final EditText adPosition = findViewById(R.id.adPosition);
        twolevel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, TwoActivity.class);
                String  adp= adPosition.getText().toString();
                int a=1;
                if (StringUtils.isNotEmpty(adp)){
                    a=Integer.parseInt(adp);
                }
                intent.putExtra("adPosition",a);
                startActivity(intent);
            }
        });
        videoshow.setVisibility(View.INVISIBLE);
        //初始化  init
        initVideoAd();

        videoload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //加载首页广告位广告
                WufunVideoAdCenter.loadVideoAd(1,"广告位 1", new WufunVideoAdCenter.VideoInterfaceCallback() {
                    @Override
                    public void onSuccess(int isOpen) {
                        ToastUtils.getInstance(activity).showToastSystem("广告加载完成");
                        videoshow.setVisibility(View.VISIBLE);
                    }

                    @Override
                    public void onFaild(String message) {
                        ToastUtils.getInstance(activity).showToastSystem("error message "+message);
                    }

                });
            }
        });
        videoshow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                videoshow.setVisibility(View.INVISIBLE);
                if (WufunVideoAdCenter.isReadyVideoAd()) {
                    String ouid="用户唯一识别id";
                    WufunVideoAdCenter.showVideoAd(ouid,1,"adposition 1",new WufunVideoAdCenter.VideoAdShowListener() {
                        @Override
                        public void onVideoAdShow() {
                            Log.e("adshowMeassage", "onVideoAdShow");
                        }

                        @Override
                        public void onVideoAdClosed() {
                            Log.e("adshowMeassage", "onVideoAdClosed");

                        }

                        @Override
                        public void onVideoAdFinish() {
                            Log.e("adshowMeassage", "onVideoAdFinish");

                        }

                        @Override
                        public void onVideoAdFail(String message) {
                            Log.e("adshowMeassage", "onVideoAdFail  " + message);

                        }
                    });
                } else {
                    ToastUtils.getInstance(activity).showToastSystem("还未准备好");
                }
            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        WufunVideoAdCenter.onRequestPermissionsResult(this, requestCode, permissions, grantResults);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //退出游戏时需要释放资源
        WufunVideoAdCenter.onExit(this);
    }
    //

    /**
     * 初始化只需要调一次即可
     */
    private void initVideoAd() {
        VideoAdData data = new VideoAdData(activity);
        WufunVideoAdCenter.initVideoAd(activity, data, new WufunVideoAdCenter.VideoInterfaceCallback() {
            @Override
            public void onSuccess(int isOpen) {
                if (isOpen == 1) {
                    ToastUtils.getInstance(activity).showToastSystem("初始化成功");
                } else {
                    ToastUtils.getInstance(activity).showToastSystem("关闭");
                }

            }

            @Override
            public void onFaild(String message) {
                ToastUtils.getInstance(activity).showToastSystem("初始化失败");
            }
        });
    }
}
