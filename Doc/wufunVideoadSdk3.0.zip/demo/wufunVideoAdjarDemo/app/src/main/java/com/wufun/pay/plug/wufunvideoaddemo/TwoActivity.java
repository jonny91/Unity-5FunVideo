package com.wufun.pay.plug.wufunvideoaddemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.wufun.pay.plug.wufunvideoadlib.WufunVideoAdCenter;

public class TwoActivity extends AppCompatActivity {
    Button showAd;
    int adPosition = 1;
    TextView message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two);
        showAd = findViewById(R.id.showAd);
        message = findViewById(R.id.message);
        adPosition = getIntent().getIntExtra("adPosition", 1);
        //加载时评广告（load video ad）
        WufunVideoAdCenter.loadVideoAd(adPosition, "广告位" + adPosition, new WufunVideoAdCenter.VideoInterfaceCallback() {
            @Override
            public void onSuccess(int i) {
                showAd.setVisibility(View.VISIBLE);
            }

            @Override
            public void onFaild(String messagex) {
                message.setText(messagex);
            }
        });
        showAd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAd.setVisibility(View.GONE);
                WufunVideoAdCenter.showVideoAd("xxx1", adPosition, "广告位" + adPosition + "（adposition 2）", new WufunVideoAdCenter.VideoAdShowListener() {
                    @Override
                    public void onVideoAdShow() {
                        Log.e("two leve adshowMeassage", "onVideoAdShow");
                    }

                    @Override
                    public void onVideoAdClosed() {
                        Log.e("two leve adshowMeassage", "onVideoAdClosed");

                    }

                    @Override
                    public void onVideoAdFinish() {
                        Log.e("two leve adshowMeassage", "onVideoAdFinish");

                    }

                    @Override
                    public void onVideoAdFail(String messagex) {
                        message.setText(messagex);
                        Log.e("two leve adshowMeassage", "onVideoAdFail  " + message);

                    }
                });
            }
        });
    }
}
